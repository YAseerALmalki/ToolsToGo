
//AdvanceModel
class AdvanceModel {
  static bool rememberMe = false;
  static String token = "";
  static String uid = "";
}