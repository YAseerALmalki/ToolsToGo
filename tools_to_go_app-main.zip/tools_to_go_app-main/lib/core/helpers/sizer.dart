import 'package:flutter/cupertino.dart';

double getWidth(BuildContext context)=> MediaQuery.sizeOf(context).width;
double getHeight(BuildContext context)=> MediaQuery.sizeOf(context).height;

Size getSize(BuildContext context)=> MediaQuery.sizeOf(context);