import 'package:flutter/cupertino.dart';

SizedBox verticalSpace(double height)=>SizedBox(height: height);
SizedBox horizontalSpace(double width)=>SizedBox(width: width);