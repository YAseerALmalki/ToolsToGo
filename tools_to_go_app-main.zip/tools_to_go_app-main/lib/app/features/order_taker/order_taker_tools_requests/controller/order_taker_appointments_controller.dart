
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:tools_to_go_app/core/helpers/get_color_status_appointments.dart';
import 'package:tools_to_go_app/core/utils/app_constant.dart';

import '../../../../../core/models/appointment.dart';
import '../../../../../core/models/notification_model.dart';
import '../../../../../core/utils/string_manager.dart';
import '../../../../../core/widgets/constants_widgets.dart';
import '../../../core/controllers/firebase/firebase_constants.dart';
import '../../../core/controllers/firebase/firebase_fun.dart';
import '../../../notification/controller/notifications_controller.dart';
import '../../../profile/controller/profile_controller.dart';

class OrderTakerAppointmentsController extends GetxController{

  final searchController = TextEditingController();
  Appointments appointments=Appointments(items: []);
  Appointments appointmentsWithFilter=Appointments(items: []);

  var getAppointments;

  @override
  void onInit() {
   searchController.clear();
   getAppointmentsFun();
    super.onInit();
    }

  getAppointmentsFun() async {
    getAppointments =_fetchAppointmentsStream();
    return getAppointments;
  }
  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }


  _fetchAppointmentsStream() {
    final result = FirebaseFirestore.instance
        .collection(FirebaseConstants.collectionAppointment)
    .where("withDelivery",isEqualTo: true)
    .where("idWorker",isNull: true)
        .snapshots();

    return result;
  }
  filter({required String term}) async {
    appointmentsWithFilter.items=[];
    appointments.items.forEach((element) {
      print(element.getState);
      print(element.toJson());
      if(element.state==ColorAppointments.StartingSoon.name)
      if((element.nameCustomer?.toLowerCase().contains(term.toLowerCase())??false)||
          (element.nameWorker?.toLowerCase().contains(term.toLowerCase())??false)||
          ((element.state??"Pending").toLowerCase().contains(term.toLowerCase())??false)
      )
          appointmentsWithFilter.items.add(element);

    });
     update();
  }


  acceptOrRejectedRequest(BuildContext context ,ColorAppointments? state,Appointment? appointment) async {
    var result;
    appointment?.state=state?.name;
    appointment?.idWorker=Get.put(ProfileController()).currentUser.value?.uid;
    appointment?.nameWorker=Get.put(ProfileController()).currentUser.value?.name;
    ConstantsWidgets.showLoading();
    {
      result=await FirebaseFun.updateAppointment(appointment:appointment!);


        //TODO dd notification
        // if(result['status'])
        //   context.read<NotificationProvider>().addNotification(context, notification: models.Notification(idUser: users[index].uid, subtitle: AppConstants.notificationSubTitleNewChat+' '+(profileProvider?.user?.firstName??''), dateTime: DateTime.now(), title: AppConstants.notificationTitleNewChat, message: ''));

        if(result['status']){
          if(state==ColorAppointments.Ongoing||state==ColorAppointments.StartingSoon){
            Get.put(NotificationsController()).addNotification(context, notification: NotificationModel(
              typeUser: AppConstants.collectionUser,
                idUser: appointment?.idUser, subtitle: StringManager.notificationSubTitleOngoingDeliveryAppointment+' '+( Get.put(ProfileController()).currentUser.value?.name??'')+' ('+(appointment.nameTool??')'), dateTime: DateTime.now(), title: StringManager.notificationTitleOngoingDeliveryAppointment, message: ''));
//             Get.put(NotificationsController()).addNotification(context, notification: NotificationModel(
//                 typeUser: AppConstants.collectionWorker,
//                 idUser: appointment?.idWorker, subtitle: StringManager.notificationSubTitleNewDeliveryAppointment+' '+(appointment.nameCustomer??''), dateTime: DateTime.now(), title: StringManager.notificationTitleNewDeliveryAppointment, message: ''))
// ;
          }

          else{
            Get.put(NotificationsController()).addNotification(context, notification: NotificationModel(
                typeUser: AppConstants.collectionUser,
                idUser: appointment?.idUser, subtitle: StringManager.notificationSubTitleCanceledAppointment+' '+(appointment.nameTool??''), dateTime: DateTime.now(), title: StringManager.notificationTitleCanceledAppointment, message: ''));

          }

          ConstantsWidgets.closeDialog();
          // if(result['status'])
          //    Get.to(ChatPage(), arguments: {'chat': controller.chat});
        }else{
          ConstantsWidgets.closeDialog();
          ConstantsWidgets.TOAST(null,
              textToast: StringManager.errorTryAgainLater
              // textToast:  tr(LocaleKeys.message_error_try_again_later)
              , state: false);
        }
      }
      // else{
      //   await LauncherHelper.launchWebsite(context,'https://wa.me/+966${person.phoneNumber?.replaceAll('+966', '')}');
      //   ConstantsWidgets.closeDialog();
      // }

    // }

  }


}
