class FirebaseConstants{

  ///--- Firebase Collections
  static String collectionUser = "Users";
  static String collectionTool = "Tools";
  static String collectionNotification = "Notifications";
  static String collectionAppointment = "Appointments";
  static String collectionChat = "Chats";
  static String collectionMessage = "Messages";
}